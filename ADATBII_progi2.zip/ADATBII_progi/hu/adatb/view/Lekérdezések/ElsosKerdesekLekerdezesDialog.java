package hu.adatb.view.Lekérdezések;

import hu.adatb.dao.Adatbazis;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class ElsosKerdesekLekerdezesDialog extends JDialog implements ActionListener {
    private JTextArea tf_lekerdez2;
    private JPanel panel_lekerdez2;
    private JButton button_lekerdez2;

    private Adatbazis adatbazis;

    public ElsosKerdesekLekerdezesDialog(Frame szuloAblak){
        super(szuloAblak, "Elsos hallgatok kérdéseinek listázésa");

        this.tf_lekerdez2 = new JTextArea();
        this.button_lekerdez2 = new JButton("Listázás");

        this.panel_lekerdez2 = new JPanel();
        this.panel_lekerdez2.setLayout(new BorderLayout());

        this.panel_lekerdez2.add(tf_lekerdez2, BorderLayout.CENTER);
        this.panel_lekerdez2.add(button_lekerdez2, BorderLayout.SOUTH);

        this.button_lekerdez2.addActionListener(this);
        this.getContentPane().add(panel_lekerdez2);

        this.pack();
        this.setSize(600, 400);

    }

    public void elokeszit(){
        this.tf_lekerdez2.setText("");

    }

    public void setAdatbazis(Adatbazis adatbazis){
        this.adatbazis = adatbazis;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String difficulty = "Elsos";
        String eredmeny = null;
        try {
            eredmeny = adatbazis.getQuestionByRoomAsDifficulty(difficulty);
        } catch (SQLException e1) {
            e1.printStackTrace();
        }
        tf_lekerdez2.setText(eredmeny);
    }
}
