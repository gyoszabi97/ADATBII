package hu.adatb.view;
public class Main {
    public static void main(String[] args) {
        InformatikusFrame informatikusFrame = new InformatikusFrame("Legyen Ön is Informatikus");
    }
}
