package hu.adatb.view.Dialogs.Puska;

public class PuskaModositasDialog {
}
