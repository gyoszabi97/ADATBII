package hu.adatb.view.Dialogs.HelyesValaszok;

public class HelyesValaszokModositasDialog {
}
