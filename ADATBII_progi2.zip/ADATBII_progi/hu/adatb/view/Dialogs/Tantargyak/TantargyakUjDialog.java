package hu.adatb.view.Dialogs.Tantargyak;
import javax.swing.*;

import hu.adatb.dao.Adatbazis;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.List;

public class TantargyakUjDialog extends JDialog implements ActionListener {
    // temakorid, nev, kreditertek
    private JTextField tf_temakorid;
    private JTextField tf_temanev;
    private JTextField tf_kreditertek;
    private JPanel panel_Panel;
    private JPanel panel_inputPanel;
    private JButton button_felviszGomb;

    public TantargyakUjDialog(Frame szuloAblak) {
        super(szuloAblak, "Új tantárgy felvétele");

        //GUI objektumok létrehozása

        this.tf_temakorid = new JTextField();
        this.tf_temanev = new JTextField();
        this.tf_kreditertek = new JTextField();
        this.button_felviszGomb = new JButton("Felvisz");

        //panelek és elrendezéseik létrehozása
        this.panel_Panel = new JPanel();
        this.panel_Panel.setLayout(new BorderLayout());
        this.panel_inputPanel = new JPanel();
        this.panel_inputPanel.setLayout(new GridLayout(3, 2));

        //Főpanel dialogablakhoz adása
        this.getContentPane().add(panel_Panel);

        //input mezők
        this.panel_inputPanel.add(new JLabel("Temakorid"));
        this.panel_inputPanel.add(this.tf_temakorid);
        this.panel_inputPanel.add(new JLabel("Temakor neve:"));
        this.panel_inputPanel.add(this.tf_temanev);
        this.panel_inputPanel.add(new JLabel("Kreditertek"));
        this.panel_inputPanel.add(this.tf_kreditertek);

        //inputpanel a főpanelhez adása, középre

        this.panel_Panel.add(panel_inputPanel, BorderLayout.CENTER);

        //felviszgomb főpanel aljához adása

        this.panel_Panel.add(button_felviszGomb, BorderLayout.SOUTH);

        //Felvisz gomb eseményfigyelője
        this.button_felviszGomb.addActionListener(this);

        this.pack();

    }
    public void elokeszit(){
        this.tf_temakorid.setText("");
        this.tf_temanev.setText("");
        this.tf_kreditertek.setText("");
    }




    public void actionPerformed(ActionEvent actionEvent) {
        Adatbazis adatbazis = new Adatbazis();
        adatbazis.connectToDatabase();
        if(actionEvent.getSource().equals(this.button_felviszGomb)){
            String table = "b_szoba";

            try {
                Adatbazis.addRecord(table, String.valueOf(tf_temakorid), String.valueOf(tf_temanev), String.valueOf(tf_kreditertek));
            } catch (SQLException e) {
                e.printStackTrace();
            }

            //List<String> tabla = adatbazis.addRecord();

            this.dispose();
        }
    }
}
