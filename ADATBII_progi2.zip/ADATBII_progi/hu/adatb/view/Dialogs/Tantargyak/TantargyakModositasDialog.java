package hu.adatb.view.Dialogs.Tantargyak;

public class TantargyakModositasDialog {
}
