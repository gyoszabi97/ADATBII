package hu.adatb.view.Dialogs.Szoba;

public class SzobaModositasDialog {
}
