package hu.adatb.view.Dialogs.Szoba;
import javax.swing.*;

import hu.adatb.dao.Adatbazis;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.List;

public class SzobaUjDialog extends JDialog implements ActionListener {
    private JTextField tf_szobanev;
    private JPanel panel_Panel;
    private JPanel panel_inputPanel;
    private JButton button_felviszGomb;

    public SzobaUjDialog(Frame szuloAblak) {
        super(szuloAblak, "Új szoba felvétele");

        //GUI objektumok létrehozása

        this.tf_szobanev = new JTextField();
        this.button_felviszGomb = new JButton("Felvisz");

        //panelek és elrendezéseik létrehozása
        this.panel_Panel = new JPanel();
        this.panel_Panel.setLayout(new BorderLayout());
        this.panel_inputPanel = new JPanel();
        this.panel_inputPanel.setLayout(new GridLayout(1, 2));

        //Főpanel dialogablakhoz adása
        this.getContentPane().add(panel_Panel);

        //input mezők
        this.panel_inputPanel.add(new JLabel("Szobanév"));
        this.panel_inputPanel.add(this.tf_szobanev);
        //inputpanel a főpanelhez adása, középre

        this.panel_Panel.add(panel_inputPanel, BorderLayout.CENTER);

        //felviszgomb főpanel aljához adása

        this.panel_Panel.add(button_felviszGomb, BorderLayout.SOUTH);

        //Felvisz gomb eseményfigyelője
        this.button_felviszGomb.addActionListener(this);

        this.pack();

    }
    public void elokeszit(){
        this.tf_szobanev.setText("");
    }




    public void actionPerformed(ActionEvent actionEvent) {
        Adatbazis adatbazis = new Adatbazis();
        adatbazis.connectToDatabase();
        if(actionEvent.getSource().equals(this.button_felviszGomb)){
            String table = "b_szoba";
            String szobanev = this.tf_szobanev.getText();

            try {
                Adatbazis.addRecord(table, szobanev);
            } catch (SQLException e) {
                e.printStackTrace();
            }

            //List<String> tabla = adatbazis.addRecord();

            this.dispose();
        }
    }
}
