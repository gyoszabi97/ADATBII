package hu.adatb.view.Dialogs.Sugo;

public class SugoModositasDialog {
}
