package hu.adatb.view.Dialogs.KreditNyeremeny;

public class KreditNyeremenyModositasDialog {
}
