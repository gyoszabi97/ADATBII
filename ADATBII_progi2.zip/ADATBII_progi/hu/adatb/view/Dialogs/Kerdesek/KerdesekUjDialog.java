package hu.adatb.view.Dialogs.Kerdesek;
import javax.swing.*;

import hu.adatb.dao.Adatbazis;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class KerdesekUjDialog extends JDialog implements ActionListener {

    /*SORREND: kerdesid, temakorid, kerdes, [0,1,2] lvid = kerdesid, valasz
				 * a-b-c-d, [0,3,4,5,6] hvid = kerdesid, betujel, helyesvalasz [0,7,8] sugo,
            * [0,0,9] puska, [0,0,10]
            */
    private JTextField tf_kerdesid;
    private JTextField tf_temakorid;
    private JTextField tf_kerdes;
    private JTextField tf_lvid;
    private JTextField tf_valaszA;
    private JTextField tf_valaszB;
    private JTextField tf_valaszC;
    private JTextField tf_valaszD;
    private JTextField tf_hvid;
    private JTextField tf_betujel;
    private JTextField tf_helyesValasz;
    private JTextField tf_sugo;
    private JTextField tf_puska;


    private JPanel panel_Panel;
    private JPanel panel_inputPanel;
    private JButton button_felviszGomb;

    public KerdesekUjDialog(Frame szuloAblak) {
        super(szuloAblak, "Új kérdés, lehetséges válaszok, helyes válasz, sugo, puska felvitele");

        //GUI objektumok létrehozása

        this.tf_kerdesid = new JTextField();
        this.tf_temakorid = new JTextField();
        this.tf_kerdes = new JTextField();
        this.tf_lvid = new JTextField();
        this.tf_valaszA = new JTextField();
        this.tf_valaszB = new JTextField();
        this.tf_valaszC = new JTextField();
        this.tf_valaszD = new JTextField();
        this.tf_hvid = new JTextField();
        this.tf_betujel = new JTextField();
        this.tf_helyesValasz = new JTextField();
        this.tf_sugo = new JTextField();
        this.tf_puska = new JTextField();
        this.button_felviszGomb = new JButton("Felvisz");

        //panelek és elrendezéseik létrehozása
        this.panel_Panel = new JPanel();
        this.panel_Panel.setLayout(new BorderLayout());
        this.panel_inputPanel = new JPanel();
        this.panel_inputPanel.setLayout(new GridLayout(15, 2));

        //Főpanel dialogablakhoz adása
        this.getContentPane().add(panel_Panel);

        /*SORREND: kerdesid, temakorid, kerdes, [0,1,2] lvid = kerdesid, valasz
         * a-b-c-d, [0,3,4,5,6] hvid = kerdesid, betujel, helyesvalasz [0,7,8] sugo,
         * [0,0,9] puska, [0,0,10]
         */

        //input mezők
        this.panel_inputPanel.add(new JLabel("kerdesid"));
        this.panel_inputPanel.add(this.tf_kerdesid);
        this.panel_inputPanel.add(new JLabel("temakorid"));
        this.panel_inputPanel.add(this.tf_temakorid);
        this.panel_inputPanel.add(new JLabel("kerdes"));
        this.panel_inputPanel.add(this.tf_kerdes);
        this.panel_inputPanel.add(new JLabel("lvid"));
        this.panel_inputPanel.add(this.tf_lvid);
        this.panel_inputPanel.add(new JLabel("A valasz"));
        this.panel_inputPanel.add(this.tf_valaszA);
        this.panel_inputPanel.add(new JLabel("B valasz"));
        this.panel_inputPanel.add(this.tf_valaszB);
        this.panel_inputPanel.add(new JLabel("c valasz"));
        this.panel_inputPanel.add(this.tf_valaszC);
        this.panel_inputPanel.add(new JLabel("D valasz"));
        this.panel_inputPanel.add(this.tf_valaszD);
        this.panel_inputPanel.add(new JLabel("hvid"));
        this.panel_inputPanel.add(this.tf_hvid);
        this.panel_inputPanel.add(new JLabel("helyes valasz betujele"));
        this.panel_inputPanel.add(this.tf_betujel);
        this.panel_inputPanel.add(new JLabel("helyes valasz"));
        this.panel_inputPanel.add(this.tf_helyesValasz);
        this.panel_inputPanel.add(new JLabel("suog"));
        this.panel_inputPanel.add(this.tf_sugo);
        this.panel_inputPanel.add(new JLabel("puska"));
        this.panel_inputPanel.add(this.tf_puska);

        //inputpanel a főpanelhez adása, középre

        this.panel_Panel.add(panel_inputPanel, BorderLayout.CENTER);

        //felviszgomb főpanel aljához adása

        this.panel_Panel.add(button_felviszGomb, BorderLayout.SOUTH);

        //Felvisz gomb eseményfigyelője
        this.button_felviszGomb.addActionListener(this);

        this.pack();

    }

    /*SORREND: kerdesid, temakorid, kerdes, [0,1,2] lvid = kerdesid, valasz
     * a-b-c-d, [0,3,4,5,6] hvid = kerdesid, betujel, helyesvalasz [0,7,8] sugo,
     * [0,0,9] puska, [0,0,10]
     */

    public void elokeszit(){

        this.tf_kerdesid.setText("");
        this.tf_temakorid.setText("");
        this.tf_kerdes.setText("");
        this.tf_lvid.setText("");
        this.tf_valaszA.setText("");
        this.tf_valaszB.setText("");
        this.tf_valaszC.setText("");
        this.tf_valaszD.setText("");
        this.tf_hvid.setText("");
        this.tf_betujel.setText("");
        this.tf_helyesValasz.setText("");
        this.tf_sugo.setText("");
        this.tf_puska.setText("");
    }




    public void actionPerformed(ActionEvent actionEvent) {
        Adatbazis adatbazis = new Adatbazis();
        adatbazis.connectToDatabase();
        if(actionEvent.getSource().equals(this.button_felviszGomb)){
            String table = "b_kerdesek";
            String kerdesid = this.tf_kerdesid.getText();
            String temakorid = this.tf_temakorid.getText();
            String kerdes = this.tf_kerdes.getText();
            String lvid = this.tf_lvid.getText();
            String valaszA = this.tf_valaszA.getText();
            String valaszB = this.tf_valaszB.getText();
            String valaszC = this.tf_valaszC.getText();
            String valaszD = this.tf_valaszD.getText();
            String hvid = this.tf_hvid.getText();
            String betujel = this.tf_betujel.getText();
            String helyesValasz = this.tf_helyesValasz.getText();
            String sugo = this.tf_sugo.getText();
            String puska = this.tf_puska.getText();

            try {
                Adatbazis.addRecord(table, kerdesid, temakorid, kerdes, lvid, valaszA, valaszB, valaszC, valaszD, hvid, betujel, helyesValasz, sugo, puska);
            } catch (SQLException e) {
                e.printStackTrace();
            }


            this.dispose();
        }
    }
}
