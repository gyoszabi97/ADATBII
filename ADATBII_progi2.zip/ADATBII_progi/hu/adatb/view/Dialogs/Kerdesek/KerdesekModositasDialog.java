package hu.adatb.view.Dialogs.Kerdesek;

public class KerdesekModositasDialog {
}
