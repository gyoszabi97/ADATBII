package hu.adatb.view.Dialogs.LehetsegesValaszok;

public class LehetsegesValaszokModositasDialog {
}
